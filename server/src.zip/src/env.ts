import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(here, "../../.env") });

/**
 * Expected environment variables (all optional except OPENROUTER_API_KEY for text):
 *
 *   OPENROUTER_API_KEY      - OpenRouter API key (sk-or-v1-...)
 *   OPENROUTER_BASE_URL     - Optional base URL (default: https://openrouter.ai/api/v1)
 *
 *   TEXT_MODEL              - Text/vision application model (alias: CHAT_MODEL)
 *                             Default: google/gemma-4-26b-a4b-it:free
 *   FLASH_MODEL             - Flash (audio/text) application model
 *   IMAGE_MODEL             - Image generation application model
 *
 *   SUPABASE_URL            - Supabase project URL (for Storage uploads)
 *   SUPABASE_SERVICE_ROLE_KEY - Supabase service-role key (server-only)
 *   SUPABASE_STORAGE_BUCKET - Generated images bucket (default: generated-images)
 *
 *   CLIENT_PORT             - Dev client port (default 5173) — CORS allowlist
 *   PORT                    - Server listen port (default 3001)
 */
