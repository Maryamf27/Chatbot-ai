import type { Response } from "express";
import type { ChatMessage } from "../types.js";

export type FlashChatArgs = {
  messages: ChatMessage[];
  res: Response;
};

export async function handleFlashChat({ res }: FlashChatArgs): Promise<void> {
  if (res.headersSent) {
    res.write(JSON.stringify({ t: "err", m: "Flash model not implemented yet." }) + "\n");
    res.end();
    return;
  }
  res.status(501).json({ error: "Flash model not implemented yet." });
}
