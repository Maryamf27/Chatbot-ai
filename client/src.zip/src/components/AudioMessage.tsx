type Props = {
  audioUrl?: string;
};

export function AudioMessage({ audioUrl }: Props) {
  return (
    <div className="audio-message" aria-disabled="true">
      <div className="audio-message-icon" aria-hidden="true">
        🔊
      </div>
      <div className="audio-message-body">
        <p className="audio-message-title">Audio message</p>
        <p className="audio-message-note">Audio playback (coming soon).</p>
        {audioUrl ? (
          <p className="audio-message-source">Source available — player pending.</p>
        ) : null}
      </div>
    </div>
  );
}
