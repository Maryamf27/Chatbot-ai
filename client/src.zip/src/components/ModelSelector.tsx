import { MODELS, type AppModel } from "../config/models";
import type { ModelId } from "../types";

type Props = {
  selectedId: ModelId;
  onChange: (id: ModelId) => void;
  disabled?: boolean;
};

export function ModelSelector({ selectedId, onChange, disabled }: Props) {
  return (
    <div className="model-selector">
      <label htmlFor="model-select" className="model-selector-label">
        Model:
      </label>
      <select
        id="model-select"
        className="model-selector-select"
        value={selectedId}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value as ModelId)}
      >
        {MODELS.map((m: AppModel) => (
          <option key={m.id} value={m.id}>
            {m.name}
          </option>
        ))}
      </select>
    </div>
  );
}
